// > sync with new json data every day but not every page refresh
// > better error handling for malformed xml
// > natural langauge airdates

$(document).ready(function() {
 
  /* * * * * * * * * * * * * * * 
  THINGS TO DO ON STARTUP
  * * * * * * * * * * * * * * */

  var shows;

  $('section').hide();
  $('section#queue').show();

  //make sure this browser is OK
  if(typeof(Storage) !== "undefined") {
    //if it is, we're all good
    $('.alert').append('Code for localStorage/sessionStorage.');
  } else {
    //otherwise, we're not all good.
    pushAlert('<Sorry! Your browser doesn\'t support HTML5 Web Storage.<br/>Upgrade to a <a href="http://outdatedbrowser.com/">modern browser</a>.');
  }

  //check for localStorage
  if (typeof localStorage.shows != "undefined"){
    //if we can, call from memory
    shows = JSON.parse(localStorage.shows);
  } else {
    //otherwise, make it an empty array and write it to localStorage
    shows = [];
    localStorage.shows = shows;
  }

  //carries subarrays of shows and their codes
  updateShows(shows);

  
  /* * * * * * * * * * * * * * * 
    INPUT AND BUTTON BEHAVIOR
    * * * * * * * * * * * * * * */

  //add show when enter is pressed
  $("#AddShowTitle").keyup(function(event){
    if(event.keyCode == 13){ 
      var title = $('#AddShowTitle').val();
      addShow(title, shows);
    }
  });

  $("#addShow").click(function(event){
    var title = $('#AddShowTitle').val();
    addShow(title, shows);
  });

  $('#Reset').click(function(){
    $(this).hide();
    $('#ResetSure').show();
    $('#ResetYes').show();
    $('#ResetNo').show();
  });

  $('#ResetYes').click(function(){
    $('#ResetSure').hide();
    $('#ResetYes').hide();
    $('#ResetNo').hide();
    $('#Reset').show();
    shows = [];
    updateShows(shows);
    pushAlert('Cleared all shows.');
  });

  $('#ResetNo').click(function(){
    $('#ResetSure').hide();
    $('#ResetYes').hide();
    $('#ResetNo').hide();
    $('#Reset').show();
  })

  //update hows when a navtab tab is clicked
  $('.navtabs li a').click(function(){
    updateShows(shows);
  });

  $('.nav-wrapper img').click(function(){
    $('ul.tabs').tabs('select_tab', 'queue')
  });

  $("#addsome").click(function(){
    goToTab('edit');
    $( "#AddShowTitle" ).focus();
  });

  $("#gotocal").click(function(){
    goToTab('calendar');
  });

  //when a tab is clicked
  $(".navtabs a").click(function(){
    var id = $(this).attr('id');
    $('main section').hide();
    $('section#'+id).show();
  });

   //when a show is clicked in the overview tab, toggle it
    $('.epsContainer a').click(
      toggleShow($(this), shows)
    );

    //when a show is clicked in the queue tab, toggle it
    $('#queue #eps a').click(
      toggleShow($(this), shows)
    );

    //if a show is deleted in the edit tab
    $('a.deleteShow').click(
      deleteShow($(this), shows);
    );

});

/* * * * * * * * * * * * * * * * * * 
  MAD FUNCTION DEFINITIONS UP IN HERE
  * * * ** * * * * * * * * * * * * * */

function goToTab(str){
  $('main section').hide();
  $('section#'+str).show();
}

function toTitleCase(str) {
  return str.replace(
    /\w\S*/g, 
    function(txt){
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    }
  );
}

//updates the shows. give it an array and it pushes changes to storage, overview, edit tab, and queue
function updateShows(shows){
  localStorage.shows = JSON.stringify(shows);
  updateYourShows(shows);
  updateOverview(shows);
  updateQueue(shows);
  updateCalendar(shows);
  $('ul.tabs').tabs();
}

function deleteShow(this, shows){
  var code = $(this).attr('id');
  $('#youSureModal').openModal();
  $('#yesDelete').click(function(){
    for (var i in shows){
      if(shows[i].showid == code){
        shows.splice(i,1);
      }
    }
    updateShows(shows);
    pushAlert('Deleted!');
  });
  $('#noDelete').click(function(){
    updateShows(shows);
    pushAlert('Not deleted! :)');
  });
}

function toggleShow(this, shows){
  //collect coordinates from html attribute
    var i = $(this).attr('i'); // which show
    var j = $(this).attr('j'); // which season
    var k = $(this).attr('k'); // which ep
    //figure out color
    var currentcolor = decideColor(shows[i].episodes.Season[j].episode[k]);
    //if it's not aired yet, nothing happens
    if (currentcolor == 'grey'){
      return;
    } else {
      //if it's unseen, mark it seen. if it's seen, mark it unseen
      $(this).toggleClass('green red');
      $(this).children('i').toggleClass('mdi-toggle-check-box-outline-blank mdi-toggle-check-box');
      shows[i].episodes.Season[j].episode[k].seen = !shows[i].episodes.Season[j].episode[k].seen;
    }
    //update localstorage, shows, and overview
    localStorage.shows = JSON.stringify(shows);
    updateYourShows(shows);
    updateOverview(shows);
}

//updates the queue tab
function updateQueue(shows){
  $(".nothingToWatch").show();
  $(".notYet").show();
  $("#eps").empty();

  //is there even anything in the queue to watch??
  var toWatch = false;
  //does a show have a card?
  var hasTitle;
  //for each show
  for (var i in shows){
    hasTitle = false;
    //for each season of the show
    for (var j in shows[i].episodes.Season){
      //for each episode of the season
      for (var k in shows[i].episodes.Season[j].episode){
        //perform a date comparison -- is there an unseen but also unaired episode?        
        var compare = Date.today().compareTo(Date.parse(shows[i].episodes.Season[j].episode[k].airdate));
        //if there is an episode unseen yet aired,
        if (shows[i].episodes.Season[j].episode[k].seen==false && compare > 0){
          //if there isn't yet a card for the show
          if (hasTitle==false){
            if (toWatch==true){ //print a newline if necessary
              $('#queue #eps').append('<br/>');
            }
            $('#queue #eps').append('<a class="waves-effect waves-light white black-text btn-flat ep"><b>'+shows[i].name+'</b></a><br/>');
            hasTitle = true;
          }
          //mark toWatch
          toWatch = true; //is there even something to watch?
          //print a card in the queue
          $("#queue #eps").append('<a class="waves-effect waves-light green lighten-1 btn ep truncate" i="' + i + '" j="' + j + '" k="' +  k +'"> <i class="mdi-toggle-check-box-outline-blank left"> </i> <b>' + (parseInt(j)+1).toString() + 'x' + shows[i].episodes.Season[j].episode[k].seasonnum+'</b> '+shows[i].episodes.Season[j].episode[k].title+' </a>');
        }
      }
    }
  }

  if (toWatch == true){
    $('.notYet').hide();
    $('.nothingToWatch').hide();        
  } else if (shows.length == 0){
    $('.nothingToWatch').hide();
  } else if (shows.length != 0){
    $('.notYet').hide();
  }

}


function updateYourShows(shows){
  //empty the #yourShows div
  $('#listYourShows').empty();
  // $('#yourShows').hide();
  // if (shows.length != 0){
  //     $('#yourShows').show();
  // }

  //create a button for every show
  for (var i in shows){
    $('#listYourShows').append("<a class='waves-effect waves-light btn white-text deleteShow cyan accent-4' id='"+shows[i].showid+"'> <i class='mdi-action-label left'></i>" + shows[i].name + " (" + shows[i].started + ") </a></li>");      
    }

  $('#listYourShows a').hover(function(){
    $(this).toggleClass('cyan red');
    // $(this).toggleClass('white-text black-text');
    $(this).children('i').toggleClass('mdi-action-label mdi-content-backspace');
  });

  

}


// <a class='btn red secondary-content deleteShow' id='"
//       + shows[i].showid
//       + "' ><i class='white-text mdi-content-clear'></i></a>


function updateOverview(input){
  var shows = input;
  $('.shows').empty();
  $(".shows").append("<ul class='collapsible' id='collapsible' data-collapsible='accordion'> </ul>");

  //for each show,...
  for (var i in shows){
    //write the accordion element and its infrastructure, which contains tabs and their content
    $(".shows .collapsible").append('<li> <div class="collapsible-header"><i class="mdi-av-movie"></i>'+shows[i].name+'</div> <div class="collapsible-body"> <div class="row" id="w'+shows[i].showid+'"> <div class="col s12"> <ul class="tabs" id="tabs'+shows[i].showid+'"></ul> </div> </div> </div> </li>');
    //make sure it's real, and then...
    if(typeof shows[i].episodes != 'undefined'){
      //for every season of the show,
      for (var j in shows[i].episodes.Season){
        //tell me the real season number
        var seasonnumber = (parseInt(j)+1).toString();
        var seasonlength = shows[i].episodes.Season.length;
        //and create a tab with that name
        $("#tabs" + shows[i].showid).append('<li class="tab col s3"><a href="#w'
          + shows[i].showid + 's' + seasonnumber + '">S' + seasonnumber 
          + '</a></li>');
        if (seasonnumber == seasonlength){
          $("a[href='#w"+shows[i].showid+"s"+seasonnumber+"']").addClass("active");
        }
        //then create the content area for that tab.
        $("#w" + shows[i].showid).append('<div id="w' + shows[i].showid + 's' 
          + seasonnumber + '" class="col s12"><div class="container epsContainer"></div></div>');
        //then, for every episode in the season,
        for (var k in shows[i].episodes.Season[j].episode){
          //tell me the real episode number
          var episodenumber = shows[i].episodes.Season[j].episode[k].seasonnum;
          //determine the color,
          var color = decideColor(shows[i].episodes.Season[j].episode[k]);
          var isChecked;
          if (color == 'red'){
            isChecked = "mdi-toggle-check-box";
          } else if (color == 'green') {
            isChecked = "mdi-toggle-check-box-outline-blank";
          } else {
            isChecked = "mdi-content-select-all";
          }
          //and write a little button block for that episode.
          $("#w" + shows[i].showid + "s" + seasonnumber + " .container")
            .append('<a class="waves-effect waves-light ' + color 
              + ' lighten-1 white-text btn ep" i="' + i + '" j="' + j + '" k="' + k + '"> <i class="' + isChecked + ' left"> </i> <b class="left">' 
              + seasonnumber + "x" + episodenumber + '</b>&nbsp; ' 
              + shows[i].episodes.Season[j].episode[k].title + '</a>');
        }
      }
    }
  }

  $('.collapsible').collapsible({ accordion : false });
  $('ul.tabs').tabs();

}

//add a show
// * title (str) : name of show, any tense
function addShow(title, shows){

  //UI stuff
  pushAlert('Searching for shows titled \"' + title + "\"");

  var working = true;
 
  //make a title ready to be queried
  var shortname = title.toLowerCase().replace(/\s/g, '-'); //NICE ONE PLANK
  $.ajax({
    url: 'http://www.jbuckland.com/ketchup.php?func=search&query=' 
    + shortname,
    dataType: "json",
    type: 'GET',
    success: function(json){

      //check if we even got anything
      if (!json.show){
        //if we didn't, tell me and cancel the whole operation
        pushAlert("We can't find the show you're looking for :(");
        $('#AddShowTitle').val('');
        return;
      }

      //if we did get something, get the first search result
      if($.isArray(json.show)) {
        json.show = json.show[0];
      }

      //check if show we found is already in our array of shows
      for (var i = 0; i < shows.length; i++){
        if (shows[i].showid == json.show.showid){
          // if it is, tell me and cancel the whole operation
          pushAlert("You're aleady watching that show!");
          $('#AddShowTitle').val('');
          return;
        }
      }
      var started;
      if (typeof json.show.started != 'undefined'){
        started = json.show.started;
      } else {
        started = "";
        json.show.started = started;
      }

      //tell the user we found a show and are getting episodes
      pushAlert("Getting episodes of \"" + json.show.name + "\" (" 
        + json.show.started + ")");
      
      //then make another ajax call for the episodes for that particular show.
      $.ajax({
        url: 'http://www.jbuckland.com/ketchup.php?func=show&query='
        + json.show.showid,
        dataType: "json",
        type: 'GET',
        success: function(kson){
          
          //if there aren't any episodes in the database, don't add the show
          if (typeof kson.Episodelist == 'undefined'){
            pushAlert("No episodes in the database :( Sorry!");
            $('#AddShowTitle').val(''); //empty the input div
            $('#addingShow').hide();
            return;
          }

          //make a new aspect of the json.show object for episodes
          json.show.episodes = kson.Episodelist;

          //open the modal to ask for options
          $('#howFarModal').openModal();
          $('#howFarModal .modal-content h4').empty();
          $('#howFarModal .modal-content p').empty();
          $('#howFarModal h4').append("<i class='mdi-content-add-box left'></i>Adding " + json.show.name);
          //initialize seen array, containing booleans for whether or not
          //a season has been seen
          var seen = [];
          //for every season of the show...
          for (var i in json.show.episodes.Season){
            //...push a false value default
            seen.push(false);
            //...and add a button to the modal.
            $('#howFarModal .modal-content p').append('<a class="waves-effect waves-light white lighten-1 black-text btn" id='+i+'> <i class="mdi-toggle-check-box-outline-blank left"></i>'+(parseInt(i)+1).toString()+'</a>');            
          }
          //print seen for testing
          // console.log(seen);
          //when a howFar season is toggled,
          $('#howFarModal p a').click(function(){
            //change its background,
            $(this).toggleClass('white green');
            //change its icon,
            $(this).children('i').toggleClass('mdi-toggle-check-box-outline-blank mdi-toggle-check-box'); 
            //change its text color,
            $(this).toggleClass('black-text white-text');
            //and change its boolean in the seen array.
            seen[$(this).attr('id')] = !seen[$(this).attr('id')]; 
            //print it for testing
            // console.log(seen);
          });

          //on Let's Go!, initialize all the seen arrays
          $('#howFarModal .modal-action').click(function(){
            //for every season of a show
            for (var i in json.show.episodes.Season){
              //if a season array isn't an array, just a single episode,
              //make it an array with that one episode. weird rare bug.
              if (!$.isArray(json.show.episodes.Season[i].episode)){
                var tmp = json.show.episodes.Season[i].episode;
                json.show.episodes.Season[i].episode = [];
                json.show.episodes.Season[i].episode[0] = tmp;
              }
              //for every episode of a season
              for (var j in json.show.episodes.Season[i].episode){
                //if the airdate is fubar, make it a millenium from now
                if(json.show.episodes.Season[i].episode[j].airdate == "0000-00-00"){
                  json.show.episodes.Season[i].episode[j].airdate = "3000-01-01";
                }

                var compare = Date.today().compareTo(Date.parse(json.show.episodes.Season[i].episode[j].airdate));
                if (compare >= "0" && seen[i]==true){
                  json.show.episodes.Season[i].episode[j]['seen'] = true;
                } else {
                  json.show.episodes.Season[i].episode[j]['seen'] = false;
                }
              }
            }
            shows.push(json.show); //push it to the shows array
            updateShows(shows); // and update everything dependent upon the shows array
            updateYourShows(shows);
            $('#AddShowTitle').val(''); //empty the input div
            pushAlert("Added \"" + json.show.name + "\" (" 
              + json.show.started + ")"); //push alert
          });
        }
      });
    }
  });
}


//pushes an alert to the box in the corner
// * str (str) : the text to be pushed
function pushAlert(str){
  Materialize.toast(str, 3000);
}

function decideColor(ep){
  var color;
  // console.log(ep);
  // console.log(Date.parse(ep.airdate));
  if ( Date.today().compareTo(Date.parse(ep.airdate)) < 0 ) {
    color = 'grey'; //unaired
  } else if (ep.seen){
    color = 'red'; //seen
  } else {
    color = 'green'; //unseen
  } 
  return color;
}

function updateCalendar(shows){
  $('tbody').empty();
  var today = Date.today().toString('MMdd');
  var diff = dateDiffInDays(Date.today(), Date.parse('last sunday'));
  var counter = diff;
  var inWeekCounter = 0;
  while (counter < (28+diff)){
    if (inWeekCounter == 0){ $('tbody').append('<tr>') }
    if (inWeekCounter == 6){ $('tbody').append('</tr>') }

    // console.log(Date.today().addDays(counter).toString('ddd MM/dd') +' '+ counter +' '+ inWeekCounter);

    $('tbody').append('<td id="' + Date.today().addDays(counter).toString('MMdd') + '"> </td>');

    counter++;
    inWeekCounter++;
    if (inWeekCounter>=7){ inWeekCounter= 0; }
  }

  // console.log(Date.today());
  // console.log(Date.today().toString('MM/dd'));
  // console.log(shows);
  for (var i in shows){
    for (var j in shows[i].episodes.Season){
      for (var k in shows[i].episodes.Season[j].episode){
        if (shows[i].episodes.Season[j].episode[k].seen == false){
          var c = Date.parse(shows[i].episodes.Season[j].episode[k].airdate).toString('MMdd');
          // console.log(c);
          $('tbody #' + c).append("<a class='btn cyan lighten-2'>" + abbrev(shows[i].name) + "</a>");
          $('tbody #' + c).append('<br/>');
        }
      }
    }
  }

  $('tbody #'+today).append('<a class="btn cyan darken-3">Today</a>');

}


var _MS_PER_DAY = 1000 * 60 * 60 * 24;
function dateDiffInDays(a, b) {
  // Discard the time and time-zone information.
  var utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
  var utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

  return Math.floor((utc2 - utc1) / _MS_PER_DAY);
}

function abbrev(str){
  if (/\s/.test(str)){
    // return str.match(/\b([A-Z])/g).join('');
    return str
  } else {
    return str;
  }
}